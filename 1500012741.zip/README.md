# DIP-Final
### I. Install requirements

```shell
$ ./install-requirement.sh
```

### II. How to test it

- 假设包含测试图片的文件夹为 testdir

```Shell
$ cd code
$ python3 evaluate.py --dir testdir
```

